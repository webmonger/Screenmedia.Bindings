/*
This file is intentionally here - DO NOT REMOVE IT!
It's used to be copied into src/ folder, since Android SDK tools fails when src folder does no exists.
All classes are distributed as compiled *.class file in attached JAR file
*/
